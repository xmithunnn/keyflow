@echo off
set "DEST=%APPDATA%\Keyflow\extension"
set "SRC=%~dp0extension"
if not exist "%DEST%" mkdir "%DEST%"
xcopy /E /I /Y "%SRC%\*" "%DEST%"
echo.
echo Keyflow installed to: %DEST%
echo.
echo Next steps:
echo   1. Open Chrome - chrome://extensions
echo   2. Enable Developer mode
echo   3. Click Load unpacked
echo   4. Select: %DEST%
pause
