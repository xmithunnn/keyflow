KEYFLOW - Installation
======================
Run INSTALL-MAC.sh (Mac) or INSTALL-WINDOWS.bat (Windows).
This copies the extension to a permanent location.
Then load it in Chrome via chrome://extensions -> Load unpacked.

Support: hello@keyflow.live
Website: https://keyflow.live
