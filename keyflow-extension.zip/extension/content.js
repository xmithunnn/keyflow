// Keyflow v2.1 — Content Script
'use strict';

const ADJACENT = {
  q:['w','a','s'],        w:['q','e','a','s','d'],   e:['w','r','s','d','f'],
  r:['e','t','d','f','g'],t:['r','y','f','g','h'],   y:['t','u','g','h','j'],
  u:['y','i','h','j','k'],i:['u','o','j','k','l'],   o:['i','p','k','l'],
  p:['o','l'],            a:['q','w','s','z'],        s:['a','w','e','d','z','x'],
  d:['s','e','r','f','x','c'],f:['d','r','t','g','c','v'],g:['f','t','y','h','v','b'],
  h:['g','y','u','j','b','n'],j:['h','u','i','k','n','m'],k:['j','i','o','l','m'],
  l:['k','o','p'],        z:['a','s','x'],            x:['z','s','d','c'],
  c:['x','d','f','v'],   v:['c','f','g','b'],         b:['v','g','h','n'],
  n:['b','h','j','m'],   m:['n','j','k']
};

let isTyping      = false;
let typingTimeout = null;

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.type === 'KEYFLOW_START' && msg.delay > 0) {
    sendResponse({ ok: true });
    setTimeout(() => startTyping(msg), msg.delay);
    return true;
  }
  if (msg.type === 'KEYFLOW_START') {
    startTyping(msg);
    sendResponse({ ok: true });
  } else if (msg.type === 'KEYFLOW_STOP') {
    stopTyping();
    sendResponse({ ok: true });
  }
  return true;
});

function stopTyping() {
  isTyping = false;
  clearTimeout(typingTimeout);
  try { chrome.runtime.sendMessage({ type: 'KEYFLOW_STOPPED' }); } catch (_) {}
}

function startTyping(config) {
  if (isTyping) stopTyping();

  const iframeEl = document.querySelector('.docs-texteventtarget-iframe');
  const isGDocs  = !!(iframeEl || document.querySelector('.kix-appview-editor') || document.querySelector('.kix-page'));

  if (isGDocs) {
    runGoogleDocs(config.text, config, iframeEl);
    return;
  }

  let target = document.activeElement;
  if (!isTypeable(target)) {
    target = document.querySelector(
      'textarea:not([readonly]), input[type="text"]:not([readonly]), [contenteditable="true"]'
    );
  }
  if (!target) {
    try { chrome.runtime.sendMessage({ type: 'KEYFLOW_ERROR', msg: "Can't find a text field." }); } catch(_) {}
    return;
  }

  const queue = buildQueue(config.text, config);
  runQueue(queue, target, config.text.length);
}

// ── Queue builder ─────────────────────────────────────────────────────────────
function buildQueue(text, config) {
  const { interval, mistakes, mistakeRate, humanize, paraPause, cursorDrift } = config;
  const queue = [];
  let charIndex = 0;
  let charsTyped = 0; // for drift counter

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];

    // ── Paragraph pause (extra delay at newlines) ──────────────────────────
    if (paraPause && ch === '\n') {
      const extraPause = 800 + Math.random() * 1800;
      queue.push({ type: 'wait', delay: extraPause, progress: null });
    }

    // ── Cursor drift (random backtrack + retype a word) ────────────────────
    if (cursorDrift && charsTyped > 0 && charsTyped % (60 + Math.floor(Math.random() * 80)) === 0) {
      // Retype last 3–7 chars
      const driftLen = 3 + Math.floor(Math.random() * 5);
      queue.push({ type: 'wait', delay: 300 + Math.random() * 400, progress: null });
      for (let d = 0; d < driftLen; d++) {
        queue.push({ type: 'delete', delay: 55 + Math.random() * 70, progress: null });
      }
      queue.push({ type: 'wait', delay: 120 + Math.random() * 200, progress: null });
      const reSlice = text.slice(Math.max(0, i - driftLen), i);
      for (const rc of reSlice) {
        queue.push({ type: 'insert', char: rc, delay: humanizeDelay(rc, interval, humanize), progress: null });
      }
    }

    const delay = humanizeDelay(ch, interval, humanize);
    const typo  = mistakes && /[a-zA-Z]/.test(ch) && ADJACENT[ch.toLowerCase()] && Math.random() < (mistakeRate / 100);

    if (typo) {
      queue.push({ type: 'insert', char: adjacentKey(ch), delay, progress: null });
      queue.push({ type: 'wait',   delay: 80 + Math.random() * 180, progress: null });
      queue.push({ type: 'delete', delay: 60 + Math.random() * 80,  progress: null });
      charIndex++;
      queue.push({ type: 'insert', char: ch, delay: 60 + Math.random() * 80, progress: charIndex });
    } else {
      charIndex++;
      queue.push({ type: 'insert', char: ch, delay, progress: charIndex });
    }
    charsTyped++;
  }
  return queue;
}

// ── Regular field runner ──────────────────────────────────────────────────────
function runQueue(queue, el, total) {
  isTyping = true;
  let idx = 0;
  function next() {
    if (!isTyping || idx >= queue.length) {
      if (isTyping) try { chrome.runtime.sendMessage({ type: 'KEYFLOW_DONE' }); } catch (_) {}
      isTyping = false; return;
    }
    const item = queue[idx++];
    if (item.type === 'wait')   { typingTimeout = setTimeout(next, item.delay); return; }
    if (item.type === 'delete') deleteChar(el);
    if (item.type === 'insert') insertChar(el, item.char);
    if (item.progress !== null) try { chrome.runtime.sendMessage({ type: 'KEYFLOW_PROGRESS', current: item.progress, total }); } catch (_) {}
    typingTimeout = setTimeout(next, item.delay);
  }
  next();
}

// ── Google Docs runner ────────────────────────────────────────────────────────
function runGoogleDocs(text, config, iframeEl) {
  let target = null;
  let doc    = document;

  if (iframeEl) {
    try {
      doc    = iframeEl.contentDocument || iframeEl.contentWindow.document;
      target = doc.querySelector('.docs-texteventtarget') ||
               doc.querySelector('[contenteditable]') ||
               doc.body;
    } catch(_) {}
  }
  if (!target) {
    target = document.querySelector('.kix-appview-editor') ||
             document.querySelector('.docs-texteventtarget') ||
             document.body;
    doc = document;
  }

  const queue = buildQueue(text, config);
  isTyping = true;
  let idx = 0;

  function next() {
    if (!isTyping || idx >= queue.length) {
      if (isTyping) try { chrome.runtime.sendMessage({ type: 'KEYFLOW_DONE' }); } catch (_) {}
      isTyping = false; return;
    }
    const item = queue[idx++];
    if (item.type === 'wait') { typingTimeout = setTimeout(next, item.delay); return; }

    if (item.type === 'delete') {
      docsKey(target, doc, 'Backspace', 8);
    } else if (item.type === 'insert') {
      item.char === '\n' ? docsKey(target, doc, 'Enter', 13) : docsInsert(target, doc, item.char);
    }

    if (item.progress !== null) try { chrome.runtime.sendMessage({ type: 'KEYFLOW_PROGRESS', current: item.progress, total: text.length }); } catch (_) {}
    typingTimeout = setTimeout(next, item.delay);
  }
  next();
}

function docsKey(target, doc, key, code) {
  const opts = { bubbles: true, cancelable: true, key, code: key, keyCode: code, which: code, charCode: 0 };
  target.dispatchEvent(new KeyboardEvent('keydown', opts));
  target.dispatchEvent(new KeyboardEvent('keyup',   opts));
}

function docsInsert(target, doc, ch) {
  const code = ch.charCodeAt(0);
  const kOpts = { bubbles: true, cancelable: true, key: ch, keyCode: code, which: code, charCode: code };
  target.dispatchEvent(new KeyboardEvent('keydown',  kOpts));
  target.dispatchEvent(new KeyboardEvent('keypress', kOpts));
  try { target.dispatchEvent(new InputEvent('textInput', { bubbles: true, cancelable: true, data: ch })); } catch(_) {}
  try { target.dispatchEvent(new InputEvent('input',     { bubbles: true, inputType: 'insertText', data: ch })); } catch(_) {}
  try { doc.execCommand('insertText', false, ch); } catch(_) {}
  target.dispatchEvent(new KeyboardEvent('keyup', kOpts));
}

// ── Helpers ───────────────────────────────────────────────────────────────────
function humanizeDelay(char, base, humanize) {
  if (!humanize) return base;
  let d = base * (0.65 + Math.random() * 0.7);
  if ('.!?'.includes(char))      d *= 2.5 + Math.random() * 3;
  else if (',;:'.includes(char)) d *= 1.4 + Math.random() * 1.5;
  else if (char === '\n')        d *= 1.8 + Math.random() * 2.5;
  return Math.max(20, Math.round(d));
}

function adjacentKey(ch) {
  const opts = ADJACENT[ch.toLowerCase()] || [];
  if (!opts.length) return ch;
  const pick = opts[Math.floor(Math.random() * opts.length)];
  return ch === ch.toUpperCase() ? pick.toUpperCase() : pick;
}

function isTypeable(el) {
  if (!el) return false;
  const tag = el.tagName?.toLowerCase();
  if (tag === 'textarea') return !el.readOnly;
  if (tag === 'input')    return !el.readOnly && ['text','search','url','email','password'].includes(el.type || 'text');
  return el.contentEditable === 'true';
}

function deleteChar(el) {
  const tag = el.tagName.toLowerCase();
  if (tag === 'textarea' || tag === 'input') {
    const s = el.selectionStart ?? el.value.length;
    if (s > 0) {
      el.value = el.value.slice(0, s - 1) + el.value.slice(el.selectionEnd ?? s);
      el.setSelectionRange(s - 1, s - 1);
      el.dispatchEvent(new Event('input', { bubbles: true }));
    }
  } else {
    const sel = window.getSelection();
    if (sel?.rangeCount) {
      const r = sel.getRangeAt(0);
      if (!r.collapsed) { r.deleteContents(); return; }
      r.setStart(r.startContainer, Math.max(0, r.startOffset - 1));
      r.deleteContents();
    }
    el.dispatchEvent(new InputEvent('input', { bubbles: true, inputType: 'deleteContentBackward' }));
  }
  el.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true, key: 'Backspace', code: 'Backspace', keyCode: 8, which: 8 }));
  el.dispatchEvent(new KeyboardEvent('keyup',   { bubbles: true, key: 'Backspace', code: 'Backspace', keyCode: 8 }));
}

function insertChar(el, char) {
  const tag = el.tagName.toLowerCase();
  if (tag === 'textarea' || tag === 'input') {
    const s = el.selectionStart ?? el.value.length;
    const e = el.selectionEnd   ?? el.value.length;
    el.value = el.value.slice(0, s) + char + el.value.slice(e);
    el.setSelectionRange(s + 1, s + 1);
    el.dispatchEvent(new Event('input',  { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  } else {
    const sel = window.getSelection();
    if (sel?.rangeCount) {
      const r = sel.getRangeAt(0);
      r.deleteContents();
      const tn = document.createTextNode(char);
      r.insertNode(tn); r.setStartAfter(tn); r.collapse(true);
      sel.removeAllRanges(); sel.addRange(r);
    } else { el.textContent += char; }
    el.dispatchEvent(new InputEvent('input', { bubbles: true, data: char, inputType: 'insertText' }));
  }
  const code = char.charCodeAt(0);
  el.dispatchEvent(new KeyboardEvent('keydown',  { bubbles: true, cancelable: true, key: char, keyCode: code, which: code }));
  el.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, cancelable: true, key: char, keyCode: code, which: code }));
  el.dispatchEvent(new KeyboardEvent('keyup',    { bubbles: true, key: char, keyCode: code, which: code }));
}
