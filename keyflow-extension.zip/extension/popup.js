'use strict';

// ─── CONFIG ──────────────────────────────────────────────────────────────────
const API_URL          = 'https://api.keyflow.app'; // Your deployed server URL
const FREE_USES_PER_WEEK = 2;
const CACHE_TTL_MS     = 24 * 60 * 60 * 1000; // re-validate every 24h

// ─── DOM ─────────────────────────────────────────────────────────────────────
const $ = id => document.getElementById(id);
const wpmRange     = $('wpm'),      wpmLabel    = $('wpm-label'),   wpmMs       = $('wpm-ms');
const textArea     = $('text'),     charCount   = $('char-count'),  charPill    = $('char-pill');
const humanizeCb   = $('humanize'), mistakesCb  = $('mistakes'),    mistakeSub  = $('mistake-sub');
const mistakeRate  = $('mistake-rate'), rateLabel = $('rate-label');
const paraPauseCb  = $('para-pause'), sessionCb  = $('session-chunks'), driftCb = $('cursor-drift');
const delaySelect  = $('delay'),    dot         = $('dot'),         statusText  = $('status-text');
const progressWrap = $('progress-wrap'), progressFill = $('progress-fill');
const progressLbl  = $('progress-label'), progressEta = $('progress-eta');
const btnStart     = $('btn-start'), btnStop     = $('btn-stop'),   etaStatic   = $('eta-static');
const platformLabel = $('platform-label'), platformChip = $('platform-chip');
const usageBar     = $('usage-bar'), usesLeft    = $('uses-left'),  resetDays   = $('reset-days');
const upgradeBtn   = $('upgrade-btn'), proBar    = $('pro-bar'),    proBarSub   = $('pro-bar-sub');
const keyStatusBar = $('key-status-bar'), keyPreview = $('key-preview'), keyTierBadge = $('key-tier-badge');
const modalOverlay = $('modal-overlay'), licenseInput = $('license-input'), licenseErr = $('license-err');
const modalCancel  = $('modal-cancel'), modalActivate = $('modal-activate');

let activeTabId = null, typingStartedAt = null;

// ─── DEVICE FINGERPRINT ───────────────────────────────────────────────────────
async function getDeviceId() {
  return new Promise(resolve => {
    chrome.storage.local.get('kf_device_id', data => {
      if (data.kf_device_id) return resolve(data.kf_device_id);
      const id = Array.from(crypto.getRandomValues(new Uint8Array(16)))
        .map(b => b.toString(16).padStart(2, '0')).join('');
      chrome.storage.local.set({ kf_device_id: id }, () => resolve(id));
    });
  });
}

// ─── LICENSE: SERVER VALIDATION ──────────────────────────────────────────────
async function validateWithServer(key, deviceId) {
  try {
    const res = await fetch(`${API_URL}/api/validate`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ key: key.trim().toUpperCase(), deviceId }),
      signal: AbortSignal.timeout(8000)
    });
    if (!res.ok) return { valid: false, error: 'Server error' };
    return await res.json(); // { valid, tier, expiresAt }
  } catch (e) {
    return { valid: false, error: 'Network error - check your connection' };
  }
}

async function activateLicense(key) {
  const deviceId = await getDeviceId();
  const result   = await validateWithServer(key, deviceId);
  if (result.valid) {
    await new Promise(resolve => chrome.storage.local.set({
      kf_key:          key.trim().toUpperCase(),
      kf_tier:         result.tier,
      kf_expires:      result.expiresAt || null,
      kf_validated_at: Date.now()
    }, resolve));
    return { success: true, tier: result.tier };
  }
  return { success: false, error: result.error || 'Invalid key. Check your email.' };
}

async function getCachedLicense() {
  return new Promise(resolve => {
    chrome.storage.local.get(['kf_key','kf_tier','kf_expires','kf_validated_at'], data => {
      if (!data.kf_key) return resolve(null);
      // Check expiry
      if (data.kf_expires && new Date(data.kf_expires) < new Date()) {
        chrome.storage.local.remove(['kf_key','kf_tier','kf_expires','kf_validated_at']);
        return resolve(null);
      }
      resolve({
        key:     data.kf_key,
        tier:    data.kf_tier || 'personal',
        expires: data.kf_expires,
        stale:   (Date.now() - (data.kf_validated_at || 0)) > CACHE_TTL_MS
      });
    });
  });
}

async function isPro() {
  const license = await getCachedLicense();
  if (!license) return false;
  // Re-validate in background if cache is stale (non-blocking)
  if (license.stale) {
    getDeviceId().then(deviceId =>
      validateWithServer(license.key, deviceId).then(result => {
        if (result.valid) {
          chrome.storage.local.set({ kf_validated_at: Date.now(), kf_tier: result.tier, kf_expires: result.expiresAt });
        } else {
          chrome.storage.local.remove(['kf_key','kf_tier','kf_expires','kf_validated_at']);
        }
      })
    ).catch(() => {});
  }
  return true;
}

// ─── USAGE (free tier) ───────────────────────────────────────────────────────
function getWeekKey() {
  const now = new Date(), soy = new Date(now.getFullYear(), 0, 1);
  const week = Math.ceil(((now - soy) / 86400000 + soy.getDay() + 1) / 7);
  return `${now.getFullYear()}-W${week}`;
}

function getDaysUntilReset() {
  const now = new Date(), sun = new Date(now);
  sun.setDate(now.getDate() + (7 - now.getDay()) % 7 || 7);
  sun.setHours(0,0,0,0);
  return Math.ceil((sun - now) / 86400000);
}

async function getUsage() {
  return new Promise(resolve => {
    chrome.storage.local.get(['kf_usage_week','kf_usage_count'], data => {
      const week  = data.kf_usage_week  || null;
      const count = data.kf_usage_count || 0;
      const cur   = getWeekKey();
      resolve({ week, count: week === cur ? count : 0 });
    });
  });
}

async function getRemainingUses() {
  const { count } = await getUsage();
  return Math.max(0, FREE_USES_PER_WEEK - count);
}

async function incrementUsage() {
  const { count } = await getUsage();
  return new Promise(resolve => {
    chrome.storage.local.set({ kf_usage_week: getWeekKey(), kf_usage_count: count + 1 }, resolve);
  });
}

// ─── UI REFRESH ───────────────────────────────────────────────────────────────
async function refreshUI() {
  const pro     = await isPro();
  const license = await getCachedLicense();

  if (pro && license) {
    usageBar.classList.add('hidden');
    proBar.classList.add('show');
    proBarSub.textContent = license.tier === 'pro' ? 'Pro plan — 2 devices' : 'Personal plan';
    keyStatusBar.classList.add('show');
    keyPreview.textContent = license.key;
    keyTierBadge.textContent = (license.tier || 'personal').toUpperCase();
    btnStart.disabled = false;
  } else {
    const remaining = await getRemainingUses();
    usageBar.classList.remove('hidden');
    proBar.classList.remove('show');
    keyStatusBar.classList.remove('show');
    usesLeft.textContent  = remaining;
    resetDays.textContent = getDaysUntilReset();
    btnStart.disabled = remaining === 0;
    if (remaining === 0) setStatus('error', 'No uses left this week. Upgrade to Pro.');
  }
}

// ─── MODAL ────────────────────────────────────────────────────────────────────
upgradeBtn.addEventListener('click', () => {
  modalOverlay.classList.add('show');
  licenseInput.value = ''; licenseErr.textContent = '';
  setTimeout(() => licenseInput.focus(), 100);
});
modalCancel.addEventListener('click', () => modalOverlay.classList.remove('show'));
modalOverlay.addEventListener('click', e => { if (e.target === modalOverlay) modalOverlay.classList.remove('show'); });

modalActivate.addEventListener('click', async () => {
  const key = licenseInput.value.trim();
  if (!key) { licenseErr.textContent = 'Enter your license key.'; return; }

  modalActivate.textContent = 'Validating...';
  modalActivate.disabled    = true;

  const result = await activateLicense(key);
  if (result.success) {
    modalOverlay.classList.remove('show');
    await refreshUI();
    setStatus('ready', 'License activated. Ready to type.');
  } else {
    licenseErr.textContent = result.error;
    modalActivate.textContent = 'Activate';
    modalActivate.disabled = false;
  }
});

licenseInput.addEventListener('keydown', e => { if (e.key === 'Enter') modalActivate.click(); });

// ─── PLATFORM DETECT ─────────────────────────────────────────────────────────
async function detectPlatform() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tab?.url) { platformLabel.textContent = 'Ready'; return; }
    const url = tab.url.toLowerCase();
    const map = [
      ['docs.google.com',   'Google Docs',  'gdocs'],
      ['classroom.google',  'GClassroom',   'gdocs'],
      ['instructure.com',   'Canvas',       'canvas'],
      ['canvas.',           'Canvas',       'canvas'],
      ['schoology.',        'Schoology',    'canvas'],
      ['turnitin.',         'Turnitin',     'canvas'],
      ['notion.so',         'Notion',       'default'],
      ['outlook.',          'Outlook',      'default'],
    ];
    for (const [host, label, cls] of map) {
      if (url.includes(host)) { platformLabel.textContent = label; platformChip.className = `platform-chip ${cls}`; return; }
    }
    platformLabel.textContent = 'Ready'; platformChip.className = 'platform-chip default';
  } catch (_) { platformLabel.textContent = 'Ready'; }
}

// ─── HELPERS ─────────────────────────────────────────────────────────────────
function msPerChar(wpm) { return Math.round(60000 / (wpm * 5)); }
function fmtTime(secs) {
  if (secs < 60) return `~${Math.ceil(secs)}s`;
  const m = Math.floor(secs/60), s = Math.ceil(secs%60);
  return s > 0 ? `~${m}m ${s}s` : `~${m}m`;
}
function updateSliderFill(input) {
  const pct = ((+input.value - +input.min) / (+input.max - +input.min)) * 100;
  input.style.setProperty('--pct', pct + '%');
}
function setStatus(state, text) { dot.className = 'dot ' + state; statusText.textContent = text; }
function updateEta() {
  const chars = textArea.value.length;
  etaStatic.textContent = chars === 0 ? '-' : fmtTime((chars / (+wpmRange.value * 5)) * 60);
}

// ─── PRESETS ─────────────────────────────────────────────────────────────────
document.querySelectorAll('.preset').forEach(btn => {
  btn.addEventListener('click', () => {
    document.querySelectorAll('.preset').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    wpmRange.value = btn.dataset.wpm;
    wpmRange.dispatchEvent(new Event('input'));
  });
});

// ─── SLIDERS ─────────────────────────────────────────────────────────────────
wpmRange.addEventListener('input', () => {
  const wpm = +wpmRange.value;
  wpmLabel.textContent = wpm + ' WPM';
  wpmMs.textContent    = wpm;
  updateSliderFill(wpmRange);
  updateEta();
  document.querySelectorAll('.preset').forEach(b => b.classList.toggle('active', +b.dataset.wpm === wpm));
});
updateSliderFill(wpmRange);

textArea.addEventListener('input', () => {
  const n = textArea.value.length;
  charCount.textContent = n.toLocaleString() + ' char' + (n !== 1 ? 's' : '');
  charPill.textContent  = n.toLocaleString();
  updateEta();
});

mistakesCb.addEventListener('change', () => mistakeSub.classList.toggle('open', mistakesCb.checked));
mistakeRate.addEventListener('input', () => { rateLabel.textContent = mistakeRate.value + '%'; updateSliderFill(mistakeRate); });
updateSliderFill(mistakeRate);

// ─── PROGRESS MESSAGES ───────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'KEYFLOW_PROGRESS') {
    const { current, total } = msg;
    const pct = Math.round((current / total) * 100);
    progressFill.style.width = pct + '%';
    progressLbl.textContent  = `${current.toLocaleString()} / ${total.toLocaleString()} chars`;
    if (typingStartedAt && current > 5) {
      const elapsed = (Date.now() - typingStartedAt) / 1000;
      const rem     = Math.max(0, (total - current) / (current / elapsed));
      progressEta.textContent = rem > 1 ? fmtTime(rem) : 'almost done';
    }
    setStatus('typing', `Typing... ${pct}%`);
  } else if (msg.type === 'KEYFLOW_DONE') {
    setStatus('done', 'Done!');
    progressFill.style.width = '100%';
    progressLbl.textContent  = 'Complete';
    progressEta.textContent  = '';
    btnStop.style.display    = 'none';
    btnStart.disabled        = false;
    btnStart.textContent     = 'Start Typing';
    refreshUI();
  } else if (msg.type === 'KEYFLOW_STOPPED') {
    setStatus('ready', 'Stopped.');
    btnStop.style.display      = 'none';
    btnStart.disabled          = false;
    btnStart.textContent       = 'Start Typing';
    progressWrap.style.display = 'none';
  } else if (msg.type === 'KEYFLOW_ERROR') {
    setStatus('error', msg.msg || "Can't type here.");
    btnStop.style.display      = 'none';
    btnStart.disabled          = false;
    btnStart.textContent       = 'Start Typing';
    progressWrap.style.display = 'none';
  }
});

// ─── START ────────────────────────────────────────────────────────────────────
btnStart.addEventListener('click', async () => {
  const text = textArea.value;
  if (!text.trim()) { setStatus('error', 'Paste some text first.'); return; }

  const pro = await isPro();
  if (!pro) {
    const remaining = await getRemainingUses();
    if (remaining <= 0) {
      setStatus('error', 'No uses left this week. Upgrade to Pro.');
      modalOverlay.classList.add('show');
      return;
    }
    await incrementUsage();
    await refreshUI();
  }

  const delay = +delaySelect.value || 0;
  const wpm   = +wpmRange.value    || 80;
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTabId = tab.id;

  btnStart.disabled          = true;
  btnStart.textContent       = delay > 0 ? `Starting in ${delay/1000}s...` : 'Typing...';
  btnStop.style.display      = 'block';
  progressWrap.style.display = 'block';
  progressFill.style.width   = '0%';
  progressLbl.textContent    = `0 / ${text.length.toLocaleString()} chars`;
  progressEta.textContent    = '';
  setStatus('typing', delay > 0 ? `Starting in ${delay/1000}s, switch tabs!` : 'Typing...');
  typingStartedAt = Date.now() + delay;

  try {
    await chrome.tabs.sendMessage(activeTabId, {
      type: 'KEYFLOW_START', text, interval: msPerChar(wpm),
      humanize: humanizeCb.checked, mistakes: mistakesCb.checked,
      mistakeRate: +mistakeRate.value || 4, paraPause: paraPauseCb.checked,
      sessionChunks: sessionCb.checked, cursorDrift: driftCb.checked, delay
    });
  } catch (e) {
    setStatus('error', "Can't reach the page. Refresh and try again.");
    btnStart.disabled          = false;
    btnStart.textContent       = 'Start Typing';
    btnStop.style.display      = 'none';
    progressWrap.style.display = 'none';
  }
});

// ─── STOP ─────────────────────────────────────────────────────────────────────
btnStop.addEventListener('click', async () => {
  if (activeTabId) { try { await chrome.tabs.sendMessage(activeTabId, { type: 'KEYFLOW_STOP' }); } catch (_) {} }
  btnStop.style.display      = 'none';
  btnStart.disabled          = false;
  btnStart.textContent       = 'Start Typing';
  setStatus('ready', 'Stopped.');
  progressWrap.style.display = 'none';
});

// ─── INIT ─────────────────────────────────────────────────────────────────────
detectPlatform();
refreshUI();
